# TodoMVC: jQuery
## Description

This application uses jQuery (3.6.3) to implement a todo application.

jQuery is a fast, small, and feature-rich JavaScript library. It makes things like HTML document traversal and manipulation, event handling, animation, and Ajax much simpler with an easy-to-use API that works across a multitude of browsers. With a combination of versatility and extensibility, jQuery has changed the way that millions of people write JavaScript.

[jQuery.com](https://jquery.com/)

## Implementation details

In contrast to mv(*) patterns, this implementation keeps display, state and app logic all within one file.
Many apps that utilize jQuery tend to keep most or all aspects within a single file for simplicity. 

## Build Steps

A simple build script copies all necessary files to a `dist` folder.
It does not rely on compilers or transpilers and serves raw html, css and js files to the user.

```
npm run build
```

## Requirements

The only requirement is an installation of Node, to be able to install dependencies and run scripts to serve a local server.

```
* Node (min version: 18.13.0)
* NPM (min version: 8.19.3)
```

## Local preview

```
terminal:
1. npm install
2. npm run dev
browser:
1. http://localhost:7001/
```
