/*global enyo:false */
enyo.depends(
	'NotepadMainView.js',
	'NotepadHeaderView.js',
	'NotepadFooterView.js',
	'FooterView.js',
	'NotepadView.js',
	'WindowView.js'
);
