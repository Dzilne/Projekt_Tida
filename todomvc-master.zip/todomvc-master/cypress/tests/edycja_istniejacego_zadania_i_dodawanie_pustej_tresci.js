describe('Edycja zadania i próba zapisania pustej treści', () => {
    it('nie powinno pozwolić zapisać pustej treści zadania', () => {
      cy.visit('http://localhost:3000');
      cy.get('.new-todo').type('Napisz raport{enter}');
      cy.get('.todo-list li').should('contain', 'Napisz raport');
  
      // Edycja zadania
      cy.get('.todo-list li').dblclick(); // Dwukrotne kliknięcie na zadanie
      cy.get('.todo-list li.editing .edit').clear().type('{enter}');
  
      // Weryfikacja, że zadanie nie zostało usunięte i wraca do poprzedniej treści
      cy.get('.todo-list li').should('contain', 'Napisz raport');
      cy.get('.todo-count').should('contain', '1 item left');
    });
  });
  