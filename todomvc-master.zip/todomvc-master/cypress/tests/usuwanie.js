describe('Usuwanie zadania z listy', () => {
    it('powinno usunąć zadanie z listy', () => {
      cy.visit('http://localhost:3000');
      cy.get('.new-todo').type('Zrobić zakupy{enter}');
      cy.get('.todo-list li').should('contain', 'Zrobić zakupy');
  
      // Usunięcie zadania
      cy.get('.todo-list li').trigger('mouseover'); // Upewniamy się, że przycisk usuwania jest widoczny
      cy.get('.todo-list li .destroy').click({ force: true });
  
      // Sprawdzanie, czy zadanie zostało usunięte
      cy.get('.todo-list li').should('not.exist');
      cy.get('.todo-count').should('contain', '0 items left');
    });
  });
  