describe('Próba dodania pustego zadania', () => {
    it('nie powinno dodać pustego zadania do listy', () => {
      cy.visit('http://localhost:3000');
      cy.get('.new-todo').type('{enter}'); // Wysłanie pustego zadania
  
      // Sprawdzanie, czy lista zadań jest pusta
      cy.get('.todo-list li').should('not.exist');
      cy.get('.todo-count').should('contain', '0 items left');
    });
  });
  