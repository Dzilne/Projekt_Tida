describe('Dodawanie nowego zadania', () => {
    it('powinno dodać nowe zadanie do listy', () => {
      cy.visit('http://localhost:3000'); // Adres aplikacji
      cy.get('.new-todo').type('Kup mleko{enter}');
      cy.get('.todo-list li').should('contain', 'Kup mleko');
      cy.get('.todo-count').should('contain', '1 item left');
    });
  });
  