describe('Oznaczanie zadania jako ukończone', () => {
    it('powinno oznaczyć zadanie jako ukończone i poprawnie zaktualizować licznik', () => {
      cy.visit('http://localhost:3000');
      cy.get('.new-todo').type('Zrobić pranie{enter}');
      cy.get('.todo-list li').should('contain', 'Zrobić pranie');
  
      // Oznaczenie zadania jako ukończone
      cy.get('.todo-list li .toggle').click();
      cy.get('.todo-list li').should('have.class', 'completed');
  
      // Sprawdzanie stanu licznika
      cy.get('.todo-count').should('contain', '0 items left');
  
      // Przechodzenie do zakładki "Completed"
      cy.contains('Completed').click();
      cy.get('.todo-list li').should('contain', 'Zrobić pranie');
    });
  });
  